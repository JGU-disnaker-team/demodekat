<?php $__env->startSection('content'); ?>
    <div class="container my-5">
        <div class="row justify-content-center">
            <div class="col-lg-5 col-md-6 col-sm-12 pricing-block">
                <form method="POST" action="<?php echo e(url('data/order/' . $data->id . '/send_konfirmasi')); ?>"
                    enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <div class="pricing-block-one active">
                        <div class="pricing-table">
                            <div class="table-header">
                                <h6>Konfirmasi Pembayaran Pesanan</h6>
                                <p>Nama Layanan : <?php echo e(@$data->layanan->title); ?></p>
                                <p>Nominal :</p>
                                <h2>Rp <?php echo e(formating_number($data->nominal, 0)); ?></h2>
                                <sub></sub>
                            </div>
                            <div class="table-body">
                                <div class="form-group">
                                    <label>Dari Bank</label>
                                    <select name="dari_bank" class="cmn-input form-select" required>
                                        <?php $__empty_1 = true; $__currentLoopData = list_bank(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $listbank): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                            <option value="<?php echo e($listbank); ?>"><?php echo e($listbank); ?>

                                            </option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                        <?php endif; ?>
                                    </select>
                                </div>
                                <div class="form-group">
                                    <label>Transfer Ke Bank</label>
                                    <select name="bank_id" class="cmn-input form-select" required>
                                        <?php $__empty_1 = true; $__currentLoopData = $data_bank; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bank): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                            <option value="<?php echo e($bank->id); ?>"><?php echo e($bank->nama . ' ' . $bank->no_rekening); ?>

                                            </option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                        <?php endif; ?>
                                    </select>
                                </div>
                                <div class="form-group">
                                    <label>Jumlah Transfer</label>
                                    <input type="number" name="nominal_transfer" class="cmn-input" value="<?php echo e($data->nominal); ?>">
                                </div>
                                <div class="form-group">
                                    <label>Bukti Transfer</label>
                                    <input type="file" name="bukti_transfer" class="cmn-input" accept="image/*">
                                </div>

                                <button type="submit" class="btn-1 w-100 text-center">Konfirmasi Pembayaran <i
                                        class="icon-arrow-1"></i></button>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ptsevelc/demodekat.solusicosmo.com/resources/views/data/order/konfirmasi.blade.php ENDPATH**/ ?>