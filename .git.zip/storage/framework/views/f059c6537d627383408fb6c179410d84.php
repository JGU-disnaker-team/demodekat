<?php $__env->startSection('content'); ?>
    <div class="container my-5 text-capitalize">
        <?php $user = Auth::user(); ?>
        <?php if (\Illuminate\Support\Facades\Blade::check('hasanyrole', 'superadmin')): ?>
            <div class="row row-cols-2 row-cols-md-5 justify-content-center">
                <div class="col">
                    <div class="card">
                        <div class="card-header">Total Order</div>

                        <div class="card-body">
                            <h5><?php echo e(formating_number(\App\Models\Order::count(), 0)); ?></h5>
                        </div>
                    </div>
                </div>
                <div class="col">
                    <div class="card">
                        <div class="card-header">Pending Order</div>

                        <div class="card-body">
                            <h5><?php echo e(formating_number(\App\Models\Order::where('status_order', 1)->count(), 0)); ?></h5>
                        </div>
                    </div>
                </div>
                <div class="col">
                    <div class="card">
                        <div class="card-header">progress Order</div>

                        <div class="card-body">
                            <h5><?php echo e(formating_number(\App\Models\Order::wherein('status_order', [2, 3])->count(), 0)); ?></h5>
                        </div>
                    </div>
                </div>
                <div class="col">
                    <div class="card">
                        <div class="card-header">Success Order</div>

                        <div class="card-body">
                            <h5><?php echo e(formating_number(\App\Models\Order::where('status_order', 4)->count(), 0)); ?></h5>
                        </div>
                    </div>
                </div>
                <div class="col">
                    <div class="card">
                        <div class="card-header">Order Dibatalkan</div>

                        <div class="card-body">
                            <h5><?php echo e(formating_number(\App\Models\Order::where('status_order', 5)->count(), 0)); ?></h5>
                        </div>
                    </div>
                </div>
            </div>
            <div class="card mt-3">
                <div class="card-header">Order menunggu</div>
                <div class="card-body">
                    <table class="table table-hover custom_datatable_data">
                        <thead>
                            <tr>
                                <th>Order</th>
                                <th>Pemesan</th>
                                <th>Waktu</th>
                                <th>Alamat</th>
                                <th>Biaya</th>
                                <th>Bukti bayar</th>
                                <th width="140px">Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = \App\Models\Order::where('status_order',1)->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pending): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td><?php echo e(@$pending->layanan->title); ?></td>
                                    <td><?php echo e(@$pending->customer->name); ?></td>
                                    <td><?php echo e($pending->waktu); ?></td>
                                    <td><?php echo e($pending->alamat); ?></td>
                                    <td><?php echo e(formating_number($pending->nominal, 0)); ?></td>
                                    <td><img src="<?php echo e($pending->bukti_transfer_url); ?>" class="img-fluid" style="width: 100px">
                                    </td>
                                    <td>
                                        <?php if($pending->status_order == '1'): ?>
                                            <?php if($pending->status_pembayaran == '2'): ?>
                                                <a href="#" data-url="<?php echo e(url('data/order/' . $pending->id . '/bayar_diterima')); ?>" class="btn btn-info btn-sm mb-1 w-100 update_data" data-bs-toggle="tooltip" title="bayar_diterima">Bayar diterima</a>
                                                <a href="#" data-url="<?php echo e(url('data/order/' . $pending->id . '/bayar_ditolak')); ?>" class="btn btn-warning btn-sm mb-1 w-100 update_data" data-bs-toggle="tooltip" title="bayar_ditolak">Bayar ditolak</a>
                                            <?php endif; ?>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
            <div class="card mt-3">
                <div class="card-header">Order Progress</div>
                <div class="card-body">
                    <table class="table table-hover custom_datatable_data">
                        <thead>
                            <tr>
                                <th>Order</th>
                                <th>worker</th>
                                <th>Pemesan</th>
                                <th>Waktu</th>
                                <th>Alamat</th>
                                <th>Biaya</th>
                                <th>status</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = \App\Models\Order::wherein('status_order',[2,3])->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $progress): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td><?php echo e(@$progress->layanan->title); ?></td>
                                    <td><?php echo e(@$progress->worker->name); ?></td>
                                    <td><?php echo e(@$progress->customer->name); ?></td>
                                    <td><?php echo e($progress->waktu); ?></td>
                                    <td><?php echo e($progress->alamat); ?></td>
                                    <td><?php echo e(formating_number($progress->nominal, 0)); ?></td>
                                    <td><?php echo e($progress->status_order_text); ?></td>

                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        <?php endif; ?>
        <?php if (\Illuminate\Support\Facades\Blade::check('hasanyrole', 'worker')): ?>
            <div class="row row-cols-2 row-cols-md-5 justify-content-center">
                <div class="col">
                    <div class="card">
                        <div class="card-header">Total Wallet</div>

                        <div class="card-body">
                            <h5><?php echo e(formating_number($user->wallet, 0)); ?></h5>
                        </div>
                    </div>
                </div>
                <div class="col">
                    <div class="card">
                        <div class="card-header">Total Order</div>

                        <div class="card-body">
                            <h5><?php echo e(formating_number(\App\Models\Order::where('worker_id', $user->id)->count(), 0)); ?></h5>
                        </div>
                    </div>
                </div>
                <div class="col">
                    <div class="card">
                        <div class="card-header">progress Order</div>

                        <div class="card-body">
                            <h5><?php echo e(formating_number(\App\Models\Order::where('worker_id', $user->id)->wherein('status_order', [2, 3])->count(),0)); ?>

                            </h5>
                        </div>
                    </div>
                </div>
                <div class="col">
                    <div class="card">
                        <div class="card-header">Success Order</div>

                        <div class="card-body">
                            <h5><?php echo e(formating_number(\App\Models\Order::where('worker_id', $user->id)->where('status_order', 4)->count(),0)); ?>

                            </h5>
                        </div>
                    </div>
                </div>
                <div class="col">
                    <div class="card">
                        <div class="card-header">Order Dibatalkan</div>

                        <div class="card-body">
                            <h5><?php echo e(formating_number(\App\Models\Order::where('worker_id', $user->id)->where('status_order', 5)->count(),0)); ?>

                            </h5>
                        </div>
                    </div>
                </div>
            </div>
            <div class="card mt-3">
                <div class="card-header">Order menunggu</div>
                <div class="card-body">
                    <table class="table table-hover custom_datatable_data">
                        <thead>
                            <tr>
                                <th>Order</th>
                                <th>Pemesan</th>
                                <th>Waktu</th>
                                <th>Alamat</th>
                                <th>Biaya</th>
                                <th width="140px">Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = \App\Models\Order::where('status_order',2)->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pending): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td><?php echo e(@$pending->layanan->title); ?></td>
                                    <td><?php echo e(@$pending->customer->name); ?></td>
                                    <td><?php echo e($pending->waktu); ?></td>
                                    <td><?php echo e($pending->alamat); ?></td>
                                    <td><?php echo e(formating_number($pending->nominal, 0)); ?></td>
                                    <td>
                                        <a href="#"
                                            data-url="<?php echo e(url('data/order/' . $pending->id . '/terima_pekerjaan')); ?>"
                                            class="btn btn-info btn-sm mb-1 w-100 update_data" data-bs-toggle="tooltip"
                                            title="terima_pekerjaan">Terima Pekerjaan</a>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
            <div class="card mt-3">
                <div class="card-header">Order Progress</div>
                <div class="card-body">
                    <table class="table table-hover custom_datatable_data">
                        <thead>
                            <tr>
                                <th>Order</th>
                                <th>Pemesan</th>
                                <th>Waktu</th>
                                <th>Alamat</th>
                                <th>Biaya</th>
                                <th>status</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = \App\Models\Order::where('worker_id',$user->id)->wherein('status_order',[2,3])->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $progress): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td><?php echo e(@$progress->layanan->title); ?></td>
                                    <td><?php echo e(@$progress->customer->name); ?></td>
                                    <td><?php echo e($progress->waktu); ?></td>
                                    <td><?php echo e($progress->alamat); ?></td>
                                    <td><?php echo e(formating_number($progress->nominal, 0)); ?></td>
                                    <td><?php echo e($progress->status_order_text); ?></td>

                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        <?php endif; ?>

        <?php if (\Illuminate\Support\Facades\Blade::check('hasanyrole', 'member')): ?>
            <div class="row row-cols-2 row-cols-md-5 justify-content-center">
                <div class="col">
                    <div class="card">
                        <div class="card-header">Total Order</div>

                        <div class="card-body">
                            <h5><?php echo e(formating_number(\App\Models\Order::where('customer_id', $user->id)->count(), 0)); ?></h5>
                        </div>
                    </div>
                </div>
                <div class="col">
                    <div class="card">
                        <div class="card-header">Pending Order</div>

                        <div class="card-body">
                            <h5><?php echo e(formating_number(\App\Models\Order::where('customer_id', $user->id)->where('status_order', 1)->count(),0)); ?>

                            </h5>
                        </div>
                    </div>
                </div>
                <div class="col">
                    <div class="card">
                        <div class="card-header">progress Order</div>

                        <div class="card-body">
                            <h5><?php echo e(formating_number(\App\Models\Order::where('customer_id', $user->id)->wherein('status_order', [2, 3])->count(),0)); ?>

                            </h5>
                        </div>
                    </div>
                </div>
                <div class="col">
                    <div class="card">
                        <div class="card-header">Success Order</div>

                        <div class="card-body">
                            <h5><?php echo e(formating_number(\App\Models\Order::where('customer_id', $user->id)->where('status_order', 4)->count(),0)); ?>

                            </h5>
                        </div>
                    </div>
                </div>
                <div class="col">
                    <div class="card">
                        <div class="card-header">Order Dibatalkan</div>

                        <div class="card-body">
                            <h5><?php echo e(formating_number(\App\Models\Order::where('customer_id', $user->id)->where('status_order', 5)->count(),0)); ?>

                            </h5>
                        </div>
                    </div>
                </div>
            </div>
            <div class="card mt-3">
                <div class="card-header">Order Aktif</div>
                <div class="card-body">
                    <table class="table table-hover custom_datatable_data">
                        <thead>
                            <tr>
                                <th>Order Layanan</th>
                                <th>Waktu</th>
                                <th>Alamat</th>
                                <th>Biaya</th>
                                <th>Pembayaran</th>
                                <th>Status Order</th>
                                <th>Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = \App\Models\Order::where('customer_id',$user->id)->wherein('status_order',[1,2,3])->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <th><?php echo e(@$order->layanan->title); ?></th>
                                    <th><?php echo e($order->waktu); ?></th>
                                    <th><?php echo e($order->alamat); ?></th>
                                    <th><?php echo e(formating_number($order->nominal, 0)); ?></th>
                                    <th><?php echo e($order->status_pembayaran_text); ?></th>
                                    <th><?php echo e($order->status_order_text); ?></th>
                                    <th>
                                        <?php if($order->status_order == 1): ?>
                                            <a href="<?php echo e(url('data/order/' . $order->id . '/konfirmasi')); ?>"
                                                class="btn btn-warning btn-sm">Konfirmasi</a>
                                        <?php elseif($order->status_order == 3): ?>
                                            <a href="#"
                                                data-url="<?php echo e(url('data/order/' . $order->id . '/selesai_pekerjaan')); ?>"
                                                class="btn btn-info btn-sm mb-1 w-100 update_data" data-bs-toggle="tooltip"
                                                title="selesai_pekerjaan">selesai Pekerjaan</a>
                                        <?php endif; ?>
                                    </th>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        <?php endif; ?>


    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ptsevelc/demodekat.solusicosmo.com/resources/views/home.blade.php ENDPATH**/ ?>