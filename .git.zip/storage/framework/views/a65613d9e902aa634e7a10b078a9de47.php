<?php $__env->startSection('content'); ?>
    <?php $user = Auth::user(); ?>
    <div class="container">
        <div class="row">
            <div class="col-md-4">
                <div class="card mb-3">
                    <div class="card-header text-capitalize">Layanan</div>
                    <div class="card-body p-0">
                        <ul class="list-group">
                            <li class="list-group-item"><?php echo e(@$data->layanan->title); ?></li>
                            <?php if($user->getRoleNames()[0] == 'superadmin' || $user->getRoleNames()[0] == 'member'): ?>
                                <li class="list-group-item"><?php echo e(@$data->layanan->harga_member); ?></li>
                            <?php endif; ?>
                            <?php if($user->getRoleNames()[0] == 'superadmin' || $user->getRoleNames()[0] == 'worker'): ?>
                                <li class="list-group-item"><?php echo e(@$data->layanan->harga_worker); ?></li>
                            <?php endif; ?>
                        </ul>
                    </div>
                </div>
                <?php if($user->getRoleNames()[0] == 'superadmin' || $user->getRoleNames()[0] == 'worker'): ?>
                    <div class="card mb-3">
                        <div class="card-header text-capitalize">Customer</div>
                        <div class="card-body p-0">
                            <ul class="list-group">
                                <li class="list-group-item"><?php echo e(@$data->customer->name); ?></li>
                                <li class="list-group-item"><?php echo e(@$data->customer->alamat); ?></li>
                                <?php if($user->getRoleNames()[0] == 'superadmin'): ?>
                                    <li class="list-group-item"><?php echo e(@$data->customer->no_telp); ?></li>
                                <?php endif; ?>
                            </ul>
                        </div>
                    </div>
                <?php endif; ?>
                <?php if($user->getRoleNames()[0] == 'superadmin' || $user->getRoleNames()[0] == 'member'): ?>
                    <div class="card mb-3">
                        <div class="card-header text-capitalize">worker</div>
                        <div class="card-body p-0">
                            <ul class="list-group">
                                <li class="list-group-item"><?php echo e(@$data->customer->name); ?></li>
                                <li class="list-group-item"><?php echo e(@$data->customer->alamat); ?></li>
                                <?php if($user->getRoleNames()[0] == 'superadmin'): ?>
                                    <li class="list-group-item"><?php echo e(@$data->customer->no_telp); ?></li>
                                <?php endif; ?>
                            </ul>
                        </div>
                    </div>
                <?php endif; ?>
            </div>
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header">Detail Order</div>
                    <div class="card-body">

                    </div>
                </div>
            </div>
        </div>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ptsevelc/demodekat.solusicosmo.com/resources/views/data/order/show.blade.php ENDPATH**/ ?>