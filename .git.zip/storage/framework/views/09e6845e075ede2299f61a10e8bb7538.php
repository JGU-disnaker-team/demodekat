<?php $__env->startSection('content'); ?>
    <!-- common banner -->
    <section class="common-banner">
        <div class="bg-layer" style="background: url('<?php echo e(asset('assets/images/background/common-banner-bg.jpg')); ?>');"></div>
        <div class="common-banner-content">
            <h3><?php echo e($data->title); ?></h3>
            <div class="breadcrumb">
                <ul>
                    <li class="breadcrumb-item active"><a href="<?php echo e(url('/')); ?>">Beranda</a></li>
                    <li class="breadcrumb-item"><i class="fa-solid fa-angles-right"></i> Detail Layanan</li>
                </ul>
            </div>
        </div>
    </section>
    <!-- common banner -->


    <!-- service details -->
    <section class="service-details">
        <div class="container">
            <div class="common-title">
                <h3><?php echo e($data->title); ?></h3>

            </div>
            <div class="row">
                <div class="col-lg-8">
                    <div class="ratio ratio-16x9 mb-4" style="background-image: url('<?php echo e($data->image_url); ?>');background-repeat: no-repeat;
    background-size: cover;">
                        
                    </div>
                    <div class="service-details-content">
                        <h4>Service Details</h4>
                        <?php echo $data->konten; ?>

                    </div>
                </div>

                <div class="col-lg-4">
                    

                    <div class="service-package">
                        <div class="service-package-name">
                            <div class="package-name">
                                <h5>Harga Layanan</h5>
                                <h5>Rp.<?php echo e(formating_number($data->harga_member,0)); ?></h5>
                            </div>
                        </div>
                        <div class="service-package-book">
                            <a href="<?php echo e(url('pesan/'.$data->id)); ?>" class="btn-1 w-100">Booking Sekarang</a>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- service details -->


    <!-- service 2 -->
    <section class="service-two pt-0" style="background-color: transparent;">
        <div class="container">
            <div class="common-title">
                <h6><i class="fa-solid fa-angles-right"></i> Layanan Lainnya </h6>
            </div>

            <div class="row">
                <?php $__empty_1 = true; $__currentLoopData = $data_related; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $related): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <div class="col-lg-3 col-md-6">
                        <div class="featured-single">
                            <div class="featured-single-image">
                                <a href="<?php echo e(url('layanan/' . $related->id)); ?>">
                                    <img src="<?php echo e($related->image_url); ?>" class="w-100" alt="image">
                                </a>
                            </div>
                            <div class="featured-single-wishlist">
                                <h6><?php echo e(@$related->kategori->title); ?></h6>
                            </div>
                            <div class="featured-single-content">

                                <a href="<?php echo e(url('layanan/' . $related->id)); ?>"><?php echo e($related->title); ?> </a>
                                <div class="featured-single-info">
                                    <div class="featured-single-info-left">
                                        <h5>Rp.<?php echo e(formating_number($related->harga_member, 0)); ?></h5>
                                    </div>
                                    <a href="<?php echo e(url('pesan/' . $related->id)); ?>">Pesan Sekarang</a>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <?php endif; ?>
            </div>
        </div>
    </section>
    <!-- service 2 -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ptsevelc/demodekat.solusicosmo.com/resources/views/frontend/layanan_detail.blade.php ENDPATH**/ ?>