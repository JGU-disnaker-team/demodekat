<?php $__env->startSection('content'); ?>
    <div class="container my-5">
        <div class="row justify-content-center">
            <div class="col-lg-4 col-md-6 col-sm-12 pricing-block">
                <div class="pricing-block-one active">
                    <div class="pricing-table">
                        <div class="table-header">
                            <h6>Pesanan Berhasil Dibuat</h6>
                            <p>Pesanan Anda Dengan Nominal </p>
                            <h2>Rp <?php echo e(formating_number($data->nominal,0)); ?></h2>
                            <sub></sub>
                        </div>
                        <div class="table-body">
                            <p>Anda bisa bayar menggunakan bank transfer berikut:</p>
                            <table class="table">
                                <tr>
                                    <th>Bank</th>
                                    <th>Nomor Rekening</th>
                                    <th>Atas Nama</th>
                                </tr>
                                <?php $__empty_1 = true; $__currentLoopData = $data_bank; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bank): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <th><?php echo e($bank->bank); ?></th>
                                    <th><?php echo e($bank->no_rekening); ?></th>
                                    <th><?php echo e($bank->nama); ?></th>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?> 
                                <?php endif; ?>
                            </table>
                           
                            <a href="<?php echo e(url('/data/order/'.$data->id.'/konfirmasi')); ?>" class="btn-1 w-100 text-center">Konfirmasi Pembayaran <i class="icon-arrow-1"></i></a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ptsevelc/demodekat.solusicosmo.com/resources/views/data/order/success_order.blade.php ENDPATH**/ ?>