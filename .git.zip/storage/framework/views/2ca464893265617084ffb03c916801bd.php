<?php $__env->startSection('content'); ?>
    <!-- banner-section -->
    <section class="banner-section-one ">
        <div class="bg-layer" style="background-image: url(<?php echo e(asset('assets/images/banner/banner-1-bg.jpg')); ?>);">
        </div>
        <div class="banner-line-shape">
            <img src="<?php echo e(asset('assets/images/shape/banner-line-shape.png')); ?>" alt="shape">
        </div>
        <div class="container">
            <div class="swiper-container">
                <div class="swiper single-item-carousel">
                    <div class="swiper-wrapper">
                        <?php $__empty_1 = true; $__currentLoopData = $slider_all; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slider): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <div class="swiper-slide testimonial-slider-item">
                                <a href="#">
                                    <img src="<?php echo e($slider->image_url); ?>" class="w-100">
                                </a>
                            </div>



                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </section>


    <!-- Categories -->
    <section class="categories">
        <div class="container">
            <div class="common-title-container">
                <div class="common-title mb-0">
                    <img src="<?php echo e(asset('assets/images/shape/title-shape-1.png')); ?>" alt="shape">
                    <h3>Kategori</h3>
                </div>
                <a href="<?php echo e(url('layanan')); ?>" class="btn-1">Selengkapnya <i class="icon-arrow-1"></i></a>
            </div>
            <div class="row">
                <?php $__empty_1 = true; $__currentLoopData = $kategori_all; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kategori): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <div class="col-lg-3 col-md-6">
                        <div class="categories-single">
                            <div class="categories-single-image">
                                <a href="<?php echo e(url('layanan?kategori=' . $kategori->id)); ?>">
                                    <img src="<?php echo e($kategori->image_url); ?>" class="w-100" alt="image">
                                </a>
                            </div>
                            <div class="categories-single-title">
                                <a href="<?php echo e(url('layanan?kategori=' . $kategori->id)); ?>"><?php echo e($kategori->title); ?> </a>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <?php endif; ?>
            </div>
        </div>
    </section>
    <!-- Categories -->


    <!-- services -->
    <section class="services">
        <div class="container">
            <div class="services-container">
                <div class="common-title text-center">
                    <h6><i class="fa-solid fa-angles-right"></i> BAGAIMANA CARA KERJANYA</h6>
                    <h3>Akses Layanan yang Mudah</h3>
                    <p></p>
                </div>
                <div class="services-one-wrapper">
                    <div class="services-one-wrapper-shape">
                        <img src="<?php echo e(asset('assets/images/shape/arrow-line.png')); ?>" alt="shape">
                    </div>
                    <div class="row">
                        <div class="col-lg-4 col-md-6">
                            <div class="service-single">
                                <div class="service-number">
                                    <h3>01</h3>
                                </div>
                                <div class="service-icon">
                                    <img src="<?php echo e(asset('assets/images/icons/service-01.png')); ?>" alt="icon">
                                </div>
                                <div class="service-single-title">
                                    <a href="<?php echo e(url('layanan')); ?>">Pilih Layanan Anda</a>
                                    <p>Pilih layanan yang Anda cari - dari website</p>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-4 col-md-6">
                            <div class="service-single">
                                <div class="service-number">
                                    <h3>02</h3>
                                </div>
                                <div class="service-icon">
                                    <img src="<?php echo e(asset('assets/images/icons/service-02.png')); ?>" alt="icon">
                                </div>
                                <div class="service-single-title">
                                    <a href="<?php echo e(url('layanan')); ?>">Pilih Jadwal Anda</a>
                                    <p>Pilih Jadwal layanan yang Anda butuhkan</p>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-4 col-md-6">
                            <div class="service-single">
                                <div class="service-number">
                                    <h3>03</h3>
                                </div>
                                <div class="service-icon">
                                    <img src="<?php echo e(asset('assets/images/icons/service-03.png')); ?>" alt="icon">
                                </div>
                                <div class="service-single-title">
                                    <a href="<?php echo e(url('layanan')); ?>">Proses Layanan</a>
                                    <p>Layanan untuk anda kami siapkan</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- services -->

    <!-- featured -->
    <section class="featured">
        <div class="container">
            <div class="common-title">
                <img src="<?php echo e(asset('assets/images/shape/title-shape-1.png')); ?>" alt="shape">
                <h6>FEATURED</h6>
                <h3>Layanan Terpopuler</h3>
            </div>
            <div class="row g-4">
                <?php $__empty_1 = true; $__currentLoopData = $layanan_all; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $layanan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <div class="col-lg-4 col-md-6">
                        <div class="featured-single">
                            <div class="featured-single-image">
                                <a href="<?php echo e(url('layanan/' . $layanan->id)); ?>">
                                    <img src="<?php echo e($layanan->image_url); ?>" class="w-100"  alt="image">
                                </a>
                            </div>
                            <div class="featured-single-wishlist">
                                <h6><?php echo e(@$layanan->kategori->title); ?></h6>
                            </div>
                            <div class="featured-single-content">

                                <a href="<?php echo e(url('layanan/' . $layanan->id)); ?>"><?php echo e($layanan->title); ?> </a>
                                <div class="featured-single-info">
                                    <div class="featured-single-info-left">
                                        <h5>Rp.<?php echo e(formating_number($layanan->harga_member, 0)); ?></h5>
                                    </div>
                                    <a href="<?php echo e(url('pesan/' . $layanan->id)); ?>">Pesan Sekarang</a>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <?php endif; ?>
            </div>
        </div>
    </section>
    <!-- featured -->

    <!-- counter -->
    <section class="counter">
        <div class="container">
            <div class="counter-container">
                <div class="counter-shape-1"><img src="<?php echo e(asset('assets/images/shape/counter-1.png')); ?>" alt="shape">
                </div>
                <div class="counter-shape-2"><img src="<?php echo e(asset('assets/images/shape/counter-2.png')); ?>" alt="shape">
                </div>
                <div class="row">
                    <div class="col-lg-3 col-md-6">
                        <div class="counter-single">
                            <div class="counter-single-inner">
                                <div class="odometer-box">
                                    <h2 class="odometer" data-count="52">00</h2>
                                    <h2 class="odometer-text">k</h2>
                                </div>
                                <h5>Customers</h5>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-6">
                        <div class="counter-single">
                            <div class="counter-single-inner">
                                <div class="odometer-box">
                                    <h2 class="odometer" data-count="42">00</h2>
                                    <h2 class="odometer-text">k</h2>
                                </div>
                                <h5>Reviews</h5>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-6">
                        <div class="counter-single">
                            <div class="counter-single-inner">
                                <div class="odometer-box">
                                    <h2 class="odometer" data-count="2">00</h2>
                                    <h2 class="odometer-text">M</h2>
                                </div>
                                <h5>Task Done</h5>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-6">
                        <div class="counter-single">
                            <div class="counter-single-inner">
                                <div class="odometer-box">
                                    <h2 class="odometer" data-count="3">00</h2>
                                    <h2 class="odometer-text">k</h2>
                                </div>
                                <h5>Jobs</h5>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- counter -->


    <!-- testimonial -->
    <section class="testimonial">
        <div class="container">
            <div class="testimonial-container">
                <div class="testimonial-bg-shape">
                    <img src="<?php echo e(asset('assets/images/shape/testimonial-bg-shape.png')); ?>" alt="shape">
                </div>
                <div class="common-title text-center">
                    <img src="<?php echo e(asset('assets/images/shape/title-shape-1.png')); ?>" alt="shape">
                    <h6>TESTIMONIAL</h6>
                    <h3>Our Stories As Told By Customers</h3>
                </div>

                <div class="testimonial-carousel">
                    <div class="swiper-container">
                        <div class="swiper single-item-carousel">
                            <div class="swiper-wrapper">


                                <?php $__empty_1 = true; $__currentLoopData = $testimoni_all; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $testimoni): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <div class="swiper-slide testimonial-slider-item">
                                        <div class="testimonial-slider-single">
                                            <div class="testimonial-slider-image">
                                                <img src="<?php echo e($testimoni->image_url); ?>" alt="<?php echo e($testimoni->nama); ?>">
                                            </div>
                                            <div class="testimonial-slider-content">
                                                <div class="rating">
                                                    <ul>
                                                        <?php for($i = 0; $i < $testimoni->rating; $i++): ?>
                                                            <li><i class="fa-sharp fa-solid fa-star"></i></li>
                                                        <?php endfor; ?>
                                                        <li><?php echo e($testimoni->rating); ?></li>
                                                    </ul>
                                                </div>
                                                <div class="testimonial-comments">
                                                    <p>
                                                        <?php echo e($testimoni->konten); ?>

                                                    </p>
                                                </div>
                                                <div class="testimonial-info-box">
                                                    <div class="testimonial-info">
                                                        <h5><?php echo e($testimoni->nama); ?></h5>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <?php endif; ?>


                            </div>
                        </div>
                    </div>
                    <div class="swiper-button-next"><i class="fa-regular fa-angle-right"></i></div>
                    <div class="swiper-button-prev"><i class="fa-sharp fa-regular fa-angle-left"></i></div>
                </div>
            </div>
        </div>
    </section>
    <!-- testimonial -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ptsevelc/demodekat.solusicosmo.com/resources/views/frontend/welcome.blade.php ENDPATH**/ ?>