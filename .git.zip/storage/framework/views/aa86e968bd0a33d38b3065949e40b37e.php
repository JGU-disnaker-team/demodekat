<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="card">
            <div class="card-header d-md-flex justify-content-between text-capitalize">
                Manage withdraw
                <?php if(Auth::user()->getRoleNames()[0] == 'worker'): ?>
                    <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#addWithdraw">
                        Add withdraw
                    </button>
                <?php endif; ?>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <?php echo e($dataTable->table()); ?>

                </div>
            </div>
        </div>
    </div>
    <div class="modal fade" id="addWithdraw" tabindex="-1" aria-labelledby="addWithdraw" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <form method="POST" action="<?php echo e(url('data/withdraw')); ?>" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                <div class="modal-header">
                    <h1 class="modal-title fs-5" id="addWithdraw">Add withdraw</h1>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <div class="col-12">
                        <?php if (isset($component)) { $__componentOriginalaf482b6af4c82cf8ea82fc4d8522b484 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalaf482b6af4c82cf8ea82fc4d8522b484 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.form.number','data' => ['label' => 'nominal','for' => 'nominal','name' => 'nominal','min' => '0','max' => ''.e(Auth::user()->wallet).'','value' => ''.e(old('nominal')).'','error' => $errors->first('nominal'),'required' => true]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('form.number'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'nominal','for' => 'nominal','name' => 'nominal','min' => '0','max' => ''.e(Auth::user()->wallet).'','value' => ''.e(old('nominal')).'','error' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($errors->first('nominal')),'required' => true]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalaf482b6af4c82cf8ea82fc4d8522b484)): ?>
<?php $attributes = $__attributesOriginalaf482b6af4c82cf8ea82fc4d8522b484; ?>
<?php unset($__attributesOriginalaf482b6af4c82cf8ea82fc4d8522b484); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalaf482b6af4c82cf8ea82fc4d8522b484)): ?>
<?php $component = $__componentOriginalaf482b6af4c82cf8ea82fc4d8522b484; ?>
<?php unset($__componentOriginalaf482b6af4c82cf8ea82fc4d8522b484); ?>
<?php endif; ?>
                        wallet anda : <?php echo e(formating_number(Auth::user()->wallet,0)); ?>

                    </div>
                    <div class="form-group">
                        <label>transfer ke Bank</label>
                        <select name="bank" class="cmn-input form-select" required>
                            <?php $__empty_1 = true; $__currentLoopData = list_bank(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $listbank): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <option value="<?php echo e($listbank); ?>"><?php echo e($listbank); ?>

                                </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <?php endif; ?>
                        </select>
                    </div>
                    <div class="col-md-12">
                        <?php if (isset($component)) { $__componentOriginal2497cd08ed4b80389f11a0f1101e9ba2 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal2497cd08ed4b80389f11a0f1101e9ba2 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.form.text','data' => ['label' => 'no_rekening','for' => 'no_rekening','name' => 'no_rekening','value' => ''.e(old('no_rekening')).'','error' => $errors->first('no_rekening'),'required' => true]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('form.text'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'no_rekening','for' => 'no_rekening','name' => 'no_rekening','value' => ''.e(old('no_rekening')).'','error' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($errors->first('no_rekening')),'required' => true]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal2497cd08ed4b80389f11a0f1101e9ba2)): ?>
<?php $attributes = $__attributesOriginal2497cd08ed4b80389f11a0f1101e9ba2; ?>
<?php unset($__attributesOriginal2497cd08ed4b80389f11a0f1101e9ba2); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2497cd08ed4b80389f11a0f1101e9ba2)): ?>
<?php $component = $__componentOriginal2497cd08ed4b80389f11a0f1101e9ba2; ?>
<?php unset($__componentOriginal2497cd08ed4b80389f11a0f1101e9ba2); ?>
<?php endif; ?>
                    </div>
                    <div class="col-md-12">
                        <?php if (isset($component)) { $__componentOriginal2497cd08ed4b80389f11a0f1101e9ba2 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal2497cd08ed4b80389f11a0f1101e9ba2 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.form.text','data' => ['label' => 'atas nama','for' => 'nama','name' => 'nama','value' => ''.e(old('nama')).'','error' => $errors->first('nama'),'required' => true]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('form.text'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'atas nama','for' => 'nama','name' => 'nama','value' => ''.e(old('nama')).'','error' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($errors->first('nama')),'required' => true]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal2497cd08ed4b80389f11a0f1101e9ba2)): ?>
<?php $attributes = $__attributesOriginal2497cd08ed4b80389f11a0f1101e9ba2; ?>
<?php unset($__attributesOriginal2497cd08ed4b80389f11a0f1101e9ba2); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2497cd08ed4b80389f11a0f1101e9ba2)): ?>
<?php $component = $__componentOriginal2497cd08ed4b80389f11a0f1101e9ba2; ?>
<?php unset($__componentOriginal2497cd08ed4b80389f11a0f1101e9ba2); ?>
<?php endif; ?>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Tutup</button>
                    <button type="submit" class="btn btn-primary">Kirim</button>
                </div>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    <?php echo e($dataTable->scripts(attributes: ['type' => 'module'])); ?>

<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ptsevelc/demodekat.solusicosmo.com/resources/views/data/withdraw/index.blade.php ENDPATH**/ ?>