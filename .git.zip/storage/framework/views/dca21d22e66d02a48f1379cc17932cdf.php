<?php $__env->startSection('content'); ?>
    <!-- common banner -->
    <section class="common-banner">
        <div class="bg-layer" style="background: url('<?php echo e(asset('assets/images/background/common-banner-bg.jpg')); ?>');"></div>
        <div class="common-banner-content">
            <h3>Pesan Layanan</h3>
            <div class="breadcrumb">
                <ul>
                    <li class="breadcrumb-item active"><a href="<?php echo e(url('/')); ?>">Beranda</a></li>
                    <li class="breadcrumb-item"><i class="fa-solid fa-angles-right"></i> Pesan Layanan</li>
                </ul>
            </div>
        </div>
    </section>
    <section class=" service-details">
        <div class="container">
            <div class="row">
                <div class="col-lg-6">
                    <div class="common-title">
                        <h4><?php echo e($data->title); ?></h4>
        
                    </div>
                    <div class="ratio ratio-16x9 mb-4"
                        style="background-image: url('<?php echo e($data->image_url); ?>');background-repeat: no-repeat;
                        background-size: cover;">

                    </div>
                    <div class="service-details-content">
                        <h4>Service Details</h4>
                        <?php echo $data->konten; ?>

                    </div>
                </div>

                <div class="col-lg-6">
                    <div class="contact-form">
                        <h3>Pesan Layanan</h3>
                        <form method="POST" action="<?php echo e(url('send_order')); ?>">
                            <?php echo csrf_field(); ?>
                            <input type="hidden" name="layanan_id" value="<?php echo e($data->id); ?>">
                            <div class="row">
                                <div class="col-lg-6">
                                    <label>Tanggal Layanan</label>
                                    <input type="date" class="cmn-input" name="waktu" value="<?php echo e(old('waktu')); ?>"
                                        required placeholder="waktu Lengkap" min="<?php echo e(date('Y-m-d')); ?>" max="<?php echo e(date('Y-m-d', strtotime('+2 days'))); ?>">
                                </div>
                                <div class="col-lg-6">
                                    
                                    <div class="form-group mb-3">
                                        <label>Jam Layanan</label>
                                        <?php echo e(Form::select('jam', jam_layanan(), null, ['class' => 'form-select'])); ?>

                                        <?php if($errors->first('jam')): ?>
                                            <small class="text-danger text-capitalize"><?php echo e($errors->first('jam')); ?></small>
                                        <?php endif; ?>
                                    </div>
                                </div>
                                <div class="col-lg-6">
                                    <label>Nomor Yang bisa di hubungi</label>
                                    <input type="text" class="cmn-input" name="no_telp" value="<?php echo e(Auth::user()->no_telp); ?>"
                                        required placeholder="+62 xxxx xxxx xxxx ">
                                </div>
                            </div>
                            
                            <div class="row">
                                <div class="col-lg-12">
                                    <label>Alamat Lengkap</label>
                                    <textarea class="cmn-input" name="alamat" required><?php echo e(Auth::user()->alamat); ?></textarea>
                                    <div class="checkbox-input">
                                        <input type="checkbox" class="form-check-input" id="term" required>
                                        <label for="term">Data Yang saya kirim adalah data yang sebenarnya dari
                                            saya</label>
                                    </div>
                                    <button type="submit" class="btn-1">Pesan Sekarang<i class="icon-arrow-1"></i></button>
                                </div>
                            </div>
                        </form>

                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- common banner -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ptsevelc/demodekat.solusicosmo.com/resources/views/frontend/pesan.blade.php ENDPATH**/ ?>