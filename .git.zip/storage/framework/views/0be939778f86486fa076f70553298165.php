 
<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="card">
            <div class="card-header d-md-flex justify-content-between text-capitalize">
                Manage order
                
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <?php echo e($dataTable->table()); ?>

                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
 
<?php $__env->startPush('scripts'); ?>
    <?php echo e($dataTable->scripts(attributes: ['type' => 'module'])); ?>

<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ptsevelc/demodekat.solusicosmo.com/resources/views/data/order/index.blade.php ENDPATH**/ ?>