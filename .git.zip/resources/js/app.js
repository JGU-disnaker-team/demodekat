import './bootstrap';
import 'laravel-datatables-vite';

let table = new DataTable('.custom_datatable_data', {
    responsive: true
});